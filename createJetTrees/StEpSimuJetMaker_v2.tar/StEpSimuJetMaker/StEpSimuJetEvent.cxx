// Test of Dijet Tree

#include "TClonesArray.h"
#include "TVector3.h"
#include "StEpSimuJetEvent.h"
#include "StEpSimuJetDef.h"
#include "StEpSimuJet.h"
#include "StEpSimuParticle.h"
#include "StEpSimuJetParticle.h"
#include "StEpSimuSubJet.h"
//#include "StForwardDijetEvent.h"
//#include "StForwardDijet.h"
//#include "StForwardJet.h"
//#include "StForwardTrack.h"
//#include "StForwardTower.h"
//#include "StForwardPYTHIA.h"

ClassImp(StEpSimuJetEvent);

  StEpSimuJetEvent::StEpSimuJetEvent()
    : mJetDefs(new TClonesArray("StEpSimuJetDef",50))
    , mJets(new TClonesArray("StEpSimuJet",50))
    , mJetParticles(new TClonesArray("StEpSimuJetParticle",50))
    , mParticles(new TClonesArray("StEpSimuParticle",50))
    , mSubJets(new TClonesArray("StEpSimuSubJet",50))
{
}

void StEpSimuJetEvent::Clear()
{
  mJetDefs->Clear();
  mJets->Clear();
  mParticles->Clear();
  //mDijets->Clear();
  //mJets->Clear();
  mJetParticles->Clear();
  mSubJets->Clear();
  //mTowers->Clear();
  //mPythia->Clear();
}

// Implement Setters
void StEpSimuJetEvent::setProcessID(int id) { mProcessID = id; }
void StEpSimuJetEvent::setTrueQ2(Double_t q2) { mTrueQ2 = q2; }
void StEpSimuJetEvent::setTrueNu(Double_t nu) { mTrueNu = nu; }
void StEpSimuJetEvent::setTrueY(Double_t y) { mTrueY = y; }
void StEpSimuJetEvent::setTrueX(Double_t x) { mTrueX = x; }
void StEpSimuJetEvent::setTrueW2(Double_t w) { mTrueW2 = w; }

void StEpSimuJetEvent::setBoost(Double_t px, Double_t py, Double_t pz, Double_t e)
{
  mBoostPx = px;
  mBoostPy = py;
  mBoostPz = pz;
  mBoostE = e;
}
void StEpSimuJetEvent::setBoostAngles(Double_t phi, Double_t theta)
{
  mBoostPhi = phi;
  mBoostTheta = theta;
}
void StEpSimuJetEvent::setGoodBoost(bool isGoodBoost)
{
  mGoodBoost = isGoodBoost;
}


// Get Number of Dijets
 //int StEpSimuJetEvent::numberOfJets() const { return mJets->GetEntriesFast(); }

// Get Number of Pythia Objects
int StEpSimuJetEvent::numberOfTotalParticles() const { return mParticles->GetEntriesFast(); }

int StEpSimuJetEvent::numberOfJetDefs() const { return mJetDefs->GetEntriesFast(); }


// Get Dijet
//StEpSimuJet* StEpSimuJetEvent::jet(int i) const { return (StEpSimuJet*)mJets->At(i); }

// Get Jet Def
StEpSimuJetDef* StEpSimuJetEvent::jetDef(int i) const { return (StEpSimuJetDef*)mJetDefs->At(i); }

// Get Pythia Object
StEpSimuParticle* StEpSimuJetEvent::particle(int i) const { return (StEpSimuParticle*)mParticles->At(i); }

// Declare New Objects
StEpSimuJet* StEpSimuJetEvent::newJet(Double_t pt, Double_t eta, Double_t phi, Double_t energy) 
{ 
  return new ((*mJets)[mJets->GetEntriesFast()]) StEpSimuJet(pt, eta, phi, energy); 
}
StEpSimuJetDef* StEpSimuJetEvent::newJetDef()
{
  return new ((*mJetDefs)[mJetDefs->GetEntriesFast()]) StEpSimuJetDef;
}
StEpSimuParticle* StEpSimuJetEvent::newParticle()
{
  return new ((*mParticles)[mParticles->GetEntriesFast()]) StEpSimuParticle;
}
StEpSimuJetParticle* StEpSimuJetEvent::newJetParticle(Double_t pt, Double_t eta, Double_t phi, Double_t energy)
{
  return new ((*mJetParticles)[mJetParticles->GetEntriesFast()]) StEpSimuJetParticle(pt, eta, phi, energy);
}
StEpSimuSubJet* StEpSimuJetEvent::newSubJet(Double_t pt, Double_t eta, Double_t phi, Double_t energy)
{
  return new ((*mSubJets)[mSubJets->GetEntriesFast()]) StEpSimuSubJet(pt, eta, phi, energy);
}



