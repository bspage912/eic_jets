// Test of Track Used with StForwardJet

#ifndef StEpSimuJetParticle_def
#define StEpSimuJetParticle_def

#include "TObject.h"
#include "TLorentzVector.h"
#include "TRef.h"
#include "TVector3.h"

class StEpSimuJetEvent;
class StEpSimuJetDef;
class StEpSimuJet;

class StEpSimuJetParticle : public TObject { 

 public:
  StEpSimuJetParticle()
    : mPt(0)
    , mEta(0)
    , mPhi(0)
    , mE(0)
    {
    }

  StEpSimuJetParticle(Double_t pt, Double_t eta, Double_t phi, Double_t energy);

  TVector3 momentum() const;
  TLorentzVector fourMomentum() const;

  // Declare Setters
  void setIndex(int id);
  //void setVertex(float x, float y, float z);
  //void setMass(float mass);  
  //void setPdgCode(int code);
  

  // Declare and Implement Getters
  Double_t pt()                      const { return mPt; }
  Double_t eta()                     const { return mEta; }
  Double_t phi()                     const { return mPhi; }
  Double_t energy()                  const { return mE; }
  Double_t index()                   const { return mIndex; }
  //float vx()                   const { return mVx; }
  //float vy()                   const { return mVy; }
  //float vz()                   const { return mVz; }
  //float mass()                 const { return mMass; }
  //float pdgCode()              const { return mPDG; }

  Double_t rap();

  // Set Jet
  void setJet(const StEpSimuJet* jet) {mJets = (TObject*)jet; }

 private:

  TRef mJets;

  Double_t    mPt;
  Double_t    mEta;
  Double_t    mPhi;
  Double_t    mE;

  int mIndex;
  //float mVx, mVy, mVz;
  //float mMass;
  //int mPDG;

  ClassDef(StEpSimuJetParticle,1);
};

inline TVector3 StEpSimuJetParticle::momentum() const
{
  TVector3 mom;
  mom.SetPtEtaPhi(mPt,mEta,mPhi);
  return mom;
}

inline TLorentzVector StEpSimuJetParticle::fourMomentum() const
{
  TLorentzVector fourMom;
  fourMom.SetPtEtaPhiE(mPt,mEta,mPhi,mE);
  return fourMom;
}

#endif
