// Test of Dijet

#include "StEpSimuJetDef.h"
#include "StEpSimuJet.h"
#include "TVector3.h"

ClassImp(StEpSimuJetDef);

StEpSimuJetDef::StEpSimuJetDef()
{
}

void StEpSimuJetDef::setRadius(float rad) { mRadius = rad; }
void StEpSimuJetDef::setMinPt(float pt) { mMinPt = pt; }
void StEpSimuJetDef::setAlgo(int algo) { mALGO = algo; }
void StEpSimuJetDef::setFrame(int frame) { mFRAME = frame; }

/*
void StForwardDijet::setTrigCombo(short trig) { mTrigCombo = trig; }
void StForwardDijet::setMass(float mass) { mMass = mass; }
void StForwardDijet::setVertex(TVector3 vertex)
{
  mVertexX = vertex.X();
  mVertexY = vertex.Y();
  mVertexZ = vertex.Z();
}

float StForwardDijet::cosPhiDiff() const
{
  StForwardJet *jet1 = jet(0);
  StForwardJet *jet2 = jet(1);

  return TMath::Cos(jet1->phi()-jet2->phi());
}

float StForwardDijet::ptBalance() const
{
  StForwardJet *same = sameSide();
  StForwardJet *away = awaySide();

  return away->pt()/same->pt();
}

float StForwardDijet::etaSum() const
{
  StForwardJet *jet1 = jet(0);
  StForwardJet *jet2 = jet(1);

  return jet1->eta() + jet2->eta();
}

float StForwardDijet::etaDiff() const
{
  StForwardJet *jet1 = jet(0);
  StForwardJet *jet2 = jet(1);

  return TMath::Abs(jet1->eta() - jet2->eta());
}

float StForwardDijet::x1Calc() const
{
  float x;
  x = (mass()/200.0)*TMath::Exp(0.5*etaSum());
  return x;
}

float StForwardDijet::x2Calc() const
{
  float x;
  x = (mass()/200.0)*TMath::Exp(-0.5*etaSum());
  return x;
}

float StForwardDijet::cosTheta() const
{
  float x;
  x = TMath::TanH(0.5*etaDiff());
  return x;
}
*/

// Get Number of Dijets
int StEpSimuJetDef::numberOfJets() const { return mJets.GetEntriesFast(); }

// Get Jet
StEpSimuJet* StEpSimuJetDef::jet(int i) const { return (StEpSimuJet*)mJets.At(i); }

/*
StForwardJet* StForwardDijet::sameSide() const
{
  StForwardJet *jet1 = jet(0);
  StForwardJet *jet2 = jet(1);

  if(jet1->isSameSide()) return jet1;
  if(jet2->isSameSide()) return jet2;
  return 0;
}

StForwardJet* StForwardDijet::awaySide() const
{
  StForwardJet *jet1 = jet(0);
  StForwardJet *jet2 = jet(1);
  
  if(!jet1->isSameSide()) return jet1;
  if(!jet2->isSameSide()) return jet2;
  return 0;
}
*/

// Add Jet to Dijet
StEpSimuJet* StEpSimuJetDef::addJet(StEpSimuJet* jet) { mJets.Add((TObject*)jet); return (StEpSimuJet*)mJets.Last(); }

